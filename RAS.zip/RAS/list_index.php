<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>RAS foirne- Candidate details</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="./style.css">
<style>
    table, th, td {
        border: 1px solid black;
        padding: 10px;
    }
</style>

</head>

<body>


   <!-- partial:index.partial.html -->
<div class="">
<//img   align="right"  src="RAS_Logo.jpg"  alt="" width="100" height="100">
   <div class="text">
     Candidate Details
   
    </div>
      
<br>
<br><br>
     <form role="form" action="indexinfo.php" method="post" enctype="multipart/form-data">
        <p><center>RAS foirne</center></p>
     <table style="width:100px">
            
            <thead>
            <tr>
                <th>Sr. No.</th>
                <th>Name</th>
                <th>Email Id</th>
                <th>Education</th>
                <th>DOB</th>
                <th>City</th>
                <th>Mobile No.</th>
                <th>Profile</th>
                <th>Experience</th>
                <th>Message</th>
                <th>CV</th>
            </tr>
            
</thead>

            <tbody>
                <?php
                include("dbconnect.php");
                $qw="SELECT  `ID`,`fnm`, `email`, `edu`, `dob`, `city`, `mob`, `prof`, `exp`, `msg`,`cv` FROM candidate ORDER BY ID DESC";
                $stmts=$mysql->prepare($qw);
                $stmts->execute();
                $i=1;
                $res=$stmts->fetchAll(PDO::FETCH_ASSOC);
                foreach($res as $row)
                {
                    echo '<tr>';
                    echo '<td>'.$i++.'</td>';
                    echo '<td>'.$row['fnm'].'</td>';
                    echo '<td>'.$row['email'].'</td>';
                    echo '<td>'.$row['edu'].'</td>';
                    echo '<td>'.$row['dob'].'</td>';
                    echo '<td>'.$row['city'].'</td>';
                    echo '<td>'.$row['mob'].'</td>';
                    echo '<td>'.$row['prof'].'</td>';
                    echo '<td>'.$row['exp'].'</td>';
                    echo '<td>'.$row['msg'].'</td>';
                    echo '<td><a href="'.$row['cv'].'" target="_blank">View CV</a></td>';
                    echo '</tr>';
                }
                $mysql=null;
                ?>
</tbody>
        </table>
        
        
            

      </form>
      </div>
<!-- partial -->
  
</body>
</html>
