<?php

date_default_timezone_set("Asia/Calcutta");
if(isset($_POST['btnsubmit']))
{
	//echo 'hey chiru..';
	
	include("dbconnect.php");
    $name=$_POST['fnm'];
	$email=$_POST['email'];
	$edu=$_POST['edu'];
	$dob=$_POST['dob'];
	$city=$_POST['city'];
	$mob=$_POST['mob'];
	$profile=$_POST['profile'];
	$exp=$_POST['exp'];
	$msg=$_POST['msg'];
	//$cv=$_POST['cv'];


	 $qw="INSERT INTO `candidate`(`fnm`, `email`, `edu`, `dob`, `city`, `mob`, `prof`, `exp`, `msg`)
      VALUES ('$name','$email','$edu','$dob','$city','$mob','$profile','$exp','$msg')";
     $stmts=$mysql->prepare($qw);
	 $stmts->execute();
	 echo $qw."<Br>";
	$lastId=$mysql->lastInsertId();	
	
	
	
	$temp = explode(".", $_FILES["cv"]["name"]);
	$extension = end($temp);
	$username='CV_'.$lastId;
	move_uploaded_file($_FILES["cv"]["tmp_name"],"cv/".$username.".".$extension);
	
	//echo "Stored in: " . "upload/" .$username.".".$extension;
	$image="cv/".$username.'.'.$extension;
	$query1 = "UPDATE candidate SET cv='$image' WHERE ID='$lastId'";
	echo $query1."<br>";
	$stmtup=$mysql->prepare($query1);
	$stmtup->execute();

        			//echo $qw."<br>"."<br>";
                   // $stmts->execute();
                     //$rw=$stmts->fetch(PDO::FETCH_ASSOC);
                    //if(empty($rw['id']))
                    //{
						//$q="insert into park_booking(fnm,adrs,email,mob,adults,children,msg)
						//values('$name','$address','$email','$mob','$adults','$child','$message')";
						//$s=$mysql->prepare($q);
						//$s->execute();
					//}
	
	$mysql=null;
}
?>