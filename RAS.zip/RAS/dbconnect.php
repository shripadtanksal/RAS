<?php
//$hostname = '103.14.97.84';
//$port = '3306';
//$username = 'rboceanw_admin';
//$password = 'rboceanw_admin';
//$dbname = 'rboceanw_db';
$hostname = 'localhost';
$port = '3306';
$username = 'root';
$password = '';
$dbname = 'test';
try {
   	 $mysql = new PDO("mysql:host=$hostname;port=$port;dbname=$dbname", $username, $password);
	 $mysql->exec("set names utf8");
   	// if($mysql)
   //  echo "COnnected";
   // else
    //echo "Not";
    }
catch(PDOException $e)
    {
    echo $e->getMessage();
    }	
	//PDO connection end
?>