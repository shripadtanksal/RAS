<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>RAS foirne- Candidate details</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
<link rel="stylesheet" href="./style.css">

</head>

<body>
   

   <!-- partial:index.partial.html -->
<div class="container">
   <div class="text">
     Candidate Details
    <img   align="left"  src="RAS_Logo.png"  alt="" width="100" height="100">
    </div>
      
<br>
<br><br>
      <form role="form" action="indexinfo.php" method="post" enctype="multipart/form-data">
         <div class="form-row">
            <div class="input-data">
               <input type="text" id="fnm" name="fnm" required>
               <div class="underline"></div>
               <br>
               <label for="">Full Name</label>
            </div>
            <div class="input-data">
               <input type="text" id="email" name="email" required>
               <div class="underline"></div>
               <label for="">Email Address</label>
            </div>
         </div>
         <div class="form-row">
            <div class="input-data">
               <input type="text" id="edu" name="edu" required>
               <div class="underline"></div>
               <label for="">Education</label>
            </div>
            <div class="input-data">
               <input type="date" id="dob" name="dob" required>
               <div class="underline"></div>
               <label for="">DOB</label>
            </div>
         </div>
         <div class="form-row">
            <div class="input-data">
               <input type="text" id="city" name="city" required>
               <div class="underline"></div>
               <label for="">City</label>
            </div>
            <div class="input-data">
               <input type="text" id="mob" name="mob" required>
               <div class="underline"></div>
               <label for="">Mob No</label>
            </div>
         </div>
         <div class="form-row">
            <div class="input-data">
               <input type="text" id="profile" name="profile" required>
               <div class="underline"></div>
               <label for="">Profile</label>
            </div>
            <div class="input-data">
               <input type="text" id="exp" name="exp" required>
               <div class="underline"></div>
               <label for="">Experence</label>
            </div>
         </div>

         <div class="form-row">
            <div class="input-data">
               <input type="file" id="cv" name="cv"  multiple required>
               <div class="underline"></div>
               <label for=""></label>
            </div>
         </div>
         <div class="form-row">
         <div class="input-data textarea">
            <textarea rows="8" cols="80"  id="msg" name="msg" required></textarea>
            <br />
            <div class="underline"></div>
            <label for="">Write your message</label>

            <div class="form-row submit-btn">
               <div class="input-data">
                  <div class="inner"></div>
                  <input type="submit" id="btnsubmit" name="btnsubmit" value="submit">
               </div>
            </div>
            <br />
            

      </form>
      </div>
<!-- partial -->
  
</body>
</html>
